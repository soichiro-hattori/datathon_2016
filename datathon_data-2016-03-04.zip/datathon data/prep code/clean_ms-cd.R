library(readr)
library(dplyr)
library(stringr)
library(foreach)
library(doMC)
registerDoMC(4)

setwd("~/Google Drive/Journal of Social Sciences 2015-2016/2015-2016 JSS Materials/DATATHON/datathon data/transactions/meal_swipes")
files <- list.files()[which(list.files() != "Icon\r")]
ms <- foreach(ii = 1:length(files), .combine = rbind) %dopar% {
  v1 <- readChar(files[ii], file.info(files[ii])$size)
  v2 <- gsub(v1, pattern = "\\r", rep = ", ")
  v3 <- gsub(v2, pattern = ", \\n", rep = "")
  v4 <- gsub(v3, pattern = "00 ", rep = "\n")
  
  d1 <- read_csv(v4, skip = 1, col_names = c('uni', 'location', 'check.no', 'time', 'check', 'transaction', 'tender.total', 'check.total'))
  d2 <- select(d1, -uni, -check, -transaction)
  mutate(d2, method = rep(as.factor("meal_swipe"), nrow(d2)))
}

ms <- arrange(ms, time)

setwd("~/Google Drive/Journal of Social Sciences 2015-2016/2015-2016 JSS Materials/DATATHON/datathon data/transactions/campus_dirhams")
files <- list.files()[which(list.files() != "Icon\r")]
cd <- foreach(ii = 1:length(files), .combine = rbind) %dopar% {
  v1 <- readChar(files[ii], file.info(files[ii])$size)
  v2 <- gsub(v1, pattern = "\\r", rep = ", ")
  v3 <- gsub(v2, pattern = ", \\n", rep = "")
  v4 <- gsub(v3, pattern = "00 ", rep = "\n")
  
  d1 <- read_csv(v4, skip = 1, col_names = c('uni', 'location', 'check.no', 'time', 'check', 'transaction', 'tender.total', 'check.total'))
  d2 <- select(d1, -uni, -check, -transaction)
  mutate(d2, method = rep(as.factor("campus_dirhams"), nrow(d2)))
}

trans <- rbind(ms, cd)
trans <- arrange(trans, time)

write_csv(trans, "~/Google Drive/Journal of Social Sciences 2015-2016/2015-2016 JSS Materials/DATATHON/datathon data/transactions/transactions.csv")


v2 <- gsub(v1, pattern = "NYU ABUDHABI", rep = "\rNYU ABUDHABI")
v3 <- gsub(v2, pattern = "NYU \r\nABUDHABI", rep = "\rNYU ABUDHABI")
# # separate column names from first column
# v6[1:2] <- str_split(v6[1], pattern = " \\\"") %>% unlist()
# v7 <- lapply(v6, FUN = gsub, pattern = " , ", rep = " ") %>% unlist()
# l1 <- str_split(v7, pattern = ",")
# d1 <- data.frame(matrix(unlist(l1), ncol = 8, byrow = T), stringsAsFactors = F) %>% tbl_df
# d2 <- d1[, c(-1,-5,-6)]
# d3 <- apply(d2, 2, gsub, pattern = "\"", rep = "") %>% as.data.frame(stringsAsFactors = F) %>% tbl_df
# colnames(d3) <- as.character(d3[1,])
# d4 <- d3[-1,]
# d5 <- separate(d4, col = `Transaction Time`, into = c("date", "time"), sep = " ")
# d5 <- rename(d4, location = `Revenue Center`, check.no = Check, time = `Transaction Time`, tender_total = `Tender Total`, check_total = `Check Total`)
# 
