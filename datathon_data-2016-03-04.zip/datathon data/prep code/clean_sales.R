library(readr)
library(dplyr)
library(stringr)
library(foreach)
library(doMC)
registerDoMC(4)

# Clean sales data .txt files
setwd("~/Google Drive/Journal of Social Sciences 2015-2016/2015-2016 JSS Materials/DATATHON/datathon data/sales/txt")
files <- list.files()[which(list.files() != "Icon\r")]
txt <- foreach(ii = 1:length(files), .combine = rbind) %dopar% {
  if(ii < 16){
    v1 <- read_lines(files[ii])
    v2 <- gsub(v1, pattern = " \\\"", rep = "\n")
    d1 <- read_csv(v2, col_names = c("item", "family", "group", "qnty.sold", "revenue", "prep.cost", "cost.perc", "marg.disc", "perc.qty", "perc.marg"))[-1,]
    d2 <- mutate(d1, item = gsub(item, pattern = "\"", rep = ""),
                 qnty.sold = gsub(qnty.sold, pattern = "\"", rep = "") %>% as.numeric(),
                 revenue = gsub(revenue, pattern = "\"", rep = "") %>% as.numeric())
  }
  # filter(d2, qnty.sold == max(na.omit(qnty.sold)))
  if(ii >= 16){
    v1 <- readChar(files[ii], file.info(files[ii])$size)
    v2 <- gsub(v1, pattern = " \\\"", rep = "")
    d1 <- read_csv(v2, col_names = c("item", "family", "group", "qnty.sold", "revenue", "prep.cost", "cost.perc", "marg.disc", "perc.qty", "perc.marg"))[-1,]
    d2 <- mutate(d1, item = gsub(item, pattern = "\"", rep = "") %>% gsub(pattern = "\\r\\n", rep = ""),
                 family = gsub(family, pattern = "\\r\\n", rep = ""),
                 group = gsub(group, pattern = "\\r\\n", rep = ""),
                 qnty.sold = gsub(qnty.sold, pattern = "\"", rep = "") %>% as.numeric(),
                 revenue = gsub(revenue, pattern = "\"", rep = "") %>% as.numeric())
  }
  d2$item <- gsub(d2$item, pattern = "\"", rep = "")
  v3 <- str_extract(files[ii], "[0-9]{6}")
  y <- substr(v3, 1, 2) %>% paste("20",., sep = "")
  m <- substr(v3, 3, 4)
  d <- substr(v3, 5, 6)
  date <- paste(y, m, sep = "-") %>% paste(d, sep = "-")
  d2$date <- as.Date(date)
  select(d2, item:revenue, date)
}

# Clean .csv files
setwd("~/Google Drive/Journal of Social Sciences 2015-2016/2015-2016 JSS Materials/DATATHON/datathon data/sales/csv")
files <- list.files()[which(list.files() != "Icon\r")]
csv <- foreach(ii = 1:length(files), .combine = rbind) %dopar% {
  d1 <- read_csv(files[ii], skip = 7)  
  colnames(d1) <- c("item", "family", "group", "qnty.sold", "revenue", "prep.cost", "cost.perc", "marg.disc", "perc.qty", "perc.marg")
  d1$date <- str_extract(files[ii], "^201[5,6]_[0-9]{2}_[0-9]{2}") %>% as.Date(format = "%Y_%m_%d")
  d2 <- select(d1, item:revenue, date)ales
  del <- c(nrow(d2) - 1, nrow(d2))
  d2[-del, ]
}

sales <- rbind(txt, csv)
sales <- mutate(sales, item = gsub(item, patt = "\\r\\n", rep = ""))
sales <- arrange(sales, date)
write_csv(sales, "~/Google Drive/Journal of Social Sciences 2015-2016/2015-2016 JSS Materials/DATATHON/datathon data/sales/sales.csv")


