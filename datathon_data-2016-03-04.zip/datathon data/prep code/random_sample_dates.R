library(dplyr)

date <- seq(as.Date("2015-08-30"), as.Date("2016-02-29"), by = "days")
day <- weekdays(date)
d1 <- data.frame(date, day)

set.seed(10)
mondays <- filter(d1, day == "Monday") %>% sample_n(10) %>% .$date
tuesdays <- filter(d1, day == "Tuesday") %>% sample_n(10) %>% .$date
wednesdays <- filter(d1, day == "Wednesday") %>% sample_n(10) %>% .$date
thursdays <- filter(d1, day == "Thursday") %>% sample_n(10) %>% .$date
fridays <- filter(d1, day == "Friday") %>% sample_n(10) %>% .$date
saturdays <- filter(d1, day == "Saturday") %>% sample_n(10) %>% .$date
sundays <- filter(d1, day == "Sunday") %>% sample_n(10) %>% .$date
c(mondays, tuesdays, wednesdays, thursdays, fridays, saturdays, sundays)

d2 <- filter(d1, !(date %in% seq(as.Date("2015-12-21"), as.Date("2016-01-27"), by = "days")))
mondays_2 <- filter(d2, day == "Monday") %>% sample_n(10) %>% .$date
tuesdays_2 <- filter(d2, day == "Tuesday") %>% sample_n(10) %>% .$date
wednesdays_2 <- filter(d2, day == "Wednesday") %>% sample_n(10) %>% .$date
thursdays_2 <- filter(d2, day == "Thursday") %>% sample_n(10) %>% .$date
fridays_2 <- filter(d2, day == "Friday") %>% sample_n(10) %>% .$date
saturdays_2 <- filter(d2, day == "Saturday") %>% sample_n(10) %>% .$date
sundays_2 <- filter(d2, day == "Sunday") %>% sample_n(10) %>% .$date

v1 <- c(mondays_2, tuesdays_2, wednesdays_2, thursdays_2, fridays_2, saturdays_2, sundays_2)

sort(v1)

