ABOUT

Welcome to the DATATHON!

In this folder, you’ll find (relatively) clean CSV files for three data sets: sales, transactions, and suggestions and accolades. Metadata files for the first two data sets are in their respective folders. 

The R code used to clean the data can be found in the prep code folder. Feel free to look through the code and raw data files.